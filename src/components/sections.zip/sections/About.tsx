import { motion } from "framer-motion";
import { FaBriefcase, FaGraduationCap, FaMapMarkerAlt } from "react-icons/fa";

import Container from "@/components/shared/Container";
import Section from "@/components/shared/Section";
import SectionTitle from "@/components/shared/SectionTitle";
import StatCard from "@/components/shared/StatCard";

import { profile } from "@/data/profile";
import { siteConfig } from "@/config/site";
import { fadeLeft, fadeRight } from "@/config/motion";
import Reveal from "@/components/ui/Reveal";

export default function About() {
  return (
    <Section id="about">
      <Reveal>
        <Container>
          <SectionTitle title="About Me" subtitle="Who Am I" />

          <div className="grid items-center gap-20 lg:grid-cols-2">
            {/* LEFT */}

            <motion.div
              variants={fadeLeft}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="flex justify-center"
            >
              <div className="relative">
                <div className="absolute inset-0 rounded-full bg-blue-500/20 blur-3xl" />

                <img
                  src={siteConfig.avatar}
                  alt={siteConfig.name}
                  className="
                  relative
                  h-80
                  w-80
                  rounded-full
                  border-8
                  border-white
                  object-cover
                  shadow-2xl
                "
                />
              </div>
            </motion.div>

            {/* RIGHT */}

            <motion.div
              variants={fadeRight}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              <h3 className="text-4xl font-black">{profile.title}</h3>

              <p className="mt-6 text-lg leading-9 text-slate-600">
                {profile.description}
              </p>

              <div className="mt-10 space-y-4">
                <InfoCard
                  icon={<FaBriefcase />}
                  title="Experience"
                  value={profile.experience}
                />

                <InfoCard
                  icon={<FaGraduationCap />}
                  title="Education"
                  value={profile.education}
                />

                <InfoCard
                  icon={<FaMapMarkerAlt />}
                  title="Location"
                  value={profile.location}
                />
              </div>

              <div className="mt-12 grid grid-cols-2 gap-5">
                {profile.stats.map((item) => (
                  <StatCard
                    key={item.label}
                    value={item.value}
                    label={item.label}
                  />
                ))}
              </div>
            </motion.div>
          </div>
        </Container>
      </Reveal>
    </Section>
  );
}

interface InfoCardProps {
  icon: React.ReactNode;
  title: string;
  value: string;
}

function InfoCard({ icon, title, value }: InfoCardProps) {
  return (
    <div
      className="
        flex
        items-center
        gap-4
        rounded-2xl
        border
        border-slate-200
        bg-white
        p-5
        shadow-sm
      "
    >
      <div
        className="
          flex
          h-12
          w-12
          items-center
          justify-center
          rounded-full
          bg-blue-100
          text-blue-600
        "
      >
        {icon}
      </div>

      <div>
        <p className="text-sm text-slate-500">{title}</p>

        <h4 className="font-semibold">{value}</h4>
      </div>
    </div>
  );
}
