import { useState } from "react";

import Container from "@/components/shared/Container";
import Section from "@/components/shared/Section";
import SectionTitle from "@/components/shared/SectionTitle";
import ProjectCard from "@/components/shared/ProjectCard";
import ProjectModal from "@/components/shared/ProjectModal";

import { projects, type Project } from "@/data/projects";
import Reveal from "@/components/ui/Reveal";

export default function Projects() {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  return (
    <>
      <Section id="projects">
        <Reveal>
          <Container>
            <SectionTitle title="Featured Projects" subtitle="My Portfolio" />

            <div
              className="
              mt-12
              grid
              gap-8
              md:grid-cols-2
              xl:grid-cols-3
            "
            >
              {projects.map((project) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  onView={setSelectedProject}
                />
              ))}
            </div>
          </Container>
        </Reveal>
      </Section>

      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />
    </>
  );
}
