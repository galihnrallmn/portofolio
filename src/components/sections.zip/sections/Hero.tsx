import { motion } from "framer-motion";
import { TypeAnimation } from "react-type-animation";
import { Link } from "react-scroll";
import {
  FaEnvelope,
  FaGithub,
  FaLinkedin,
  FaMapMarkerAlt,
} from "react-icons/fa";

import Button from "@/components/shared/Button";
import SocialButton from "@/components/shared/SocialButton";

import { siteConfig } from "@/config/site";
import { fadeLeft, fadeRight, floating } from "@/config/motion";

export default function Hero() {
  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center overflow-hidden"
    >
      {/* Background */}
      <div className="absolute -left-40 top-0 h-96 w-96 rounded-full bg-blue-500/20 blur-3xl" />

      <div className="absolute bottom-0 right-0 h-[420px] w-[420px] rounded-full bg-cyan-400/20 blur-3xl" />

      {/* Grid */}
      <div className="absolute inset-0 -z-10 bg-[linear-gradient(to_right,#e2e8f020_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f020_1px,transparent_1px)] bg-[size:45px_45px]" />

      <div
        className="
          relative
          mx-auto
          grid
          w-full
          max-w-7xl
          grid-cols-1
          items-center
          gap-20
          px-6
          pb-20
          pt-32
          lg:grid-cols-2
          lg:px-8
        "
      >
        {/* LEFT */}
        <motion.div variants={fadeLeft} initial="hidden" animate="visible">
          <div
            className="
              inline-flex
              items-center
              gap-2
              rounded-full
              border
              border-blue-200
              bg-blue-50
              px-4
              py-2
              text-sm
              font-medium
              text-blue-700
            "
          >
            👋 Hello, I'm
          </div>

          <h1
            className="
              mt-6
              text-5xl
              font-black
              leading-tight
              text-slate-900
              lg:text-7xl
            "
          >
            {siteConfig.name}
          </h1>

          <div className="mt-6 h-12">
            <TypeAnimation
              sequence={[
                "Web Developer",
                2000,
                "React Developer",
                2000,
                "Laravel Developer",
                2000,
                "Frontend Developer",
                2000,
                "Freelancer",
                2000,
              ]}
              wrapper="span"
              speed={45}
              repeat={Infinity}
              className="text-2xl font-bold text-blue-600 lg:text-3xl"
            />
          </div>

          <p
            className="
              mt-8
              max-w-xl
              text-lg
              leading-8
              text-slate-600
            "
          >
            {siteConfig.description}
          </p>

          {/* Badge */}

          <div className="mt-8 flex flex-wrap gap-3">
            <div className="rounded-full bg-slate-100 px-4 py-2 text-sm">
              📍 {siteConfig.location}
            </div>

            <div className="rounded-full bg-green-100 px-4 py-2 text-sm text-green-700">
              💼 Available for Freelance
            </div>
          </div>

          {/* CTA */}

          <div className="mt-10 flex flex-wrap gap-4">
            <Link to="projects" smooth duration={500} offset={-80}>
              <Button>View Projects</Button>
            </Link>

            <a href={siteConfig.cv} download>
              <Button variant="secondary">Download CV</Button>
            </a>
          </div>

          {/* Social */}

          <div className="mt-10 flex gap-4">
            <SocialButton
              icon={FaGithub}
              href={siteConfig.github}
              label="GitHub"
            />

            <SocialButton
              icon={FaLinkedin}
              href={siteConfig.linkedin}
              label="LinkedIn"
            />

            <SocialButton
              icon={FaEnvelope}
              href={`mailto:${siteConfig.email}`}
              label="Email"
            />
          </div>
        </motion.div>

        {/* RIGHT */}

        <motion.div
          variants={fadeRight}
          initial="hidden"
          animate="visible"
          className="flex justify-center"
        >
          <motion.div animate={floating} className="relative">
            {/* Glow */}
            <div className="absolute inset-0 rounded-full bg-blue-500 opacity-20 blur-3xl" />

            {/* Status */}
            <div
              className="
                absolute
                -right-3
                top-8
                z-20
                rounded-full
                bg-green-500
                px-4
                py-2
                text-sm
                font-semibold
                text-white
                shadow-lg
              "
            >
              Available
            </div>

            <img
              src={siteConfig.avatar}
              alt={siteConfig.name}
              loading="lazy"
              decoding="async"
              className="
                relative
                h-72
                w-72
                rounded-full
                border-8
                border-white
                object-cover
                shadow-2xl
                lg:h-[420px]
                lg:w-[420px]
              "
            />

            {/* Card */}
            <div
              className="
                absolute
                -bottom-8
                left-1/2
                w-[260px]
                -translate-x-1/2
                rounded-3xl
                border
                border-white/40
                bg-white/80
                p-5
                shadow-xl
                backdrop-blur-xl
              "
            >
              <div className="flex items-center gap-3">
                <FaMapMarkerAlt className="text-blue-600" />

                <div>
                  <p className="text-xs text-slate-500">Based in</p>

                  <p className="font-semibold">{siteConfig.location}</p>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}

      <motion.div
        animate={{
          y: [0, 12, 0],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
        }}
        className="
          absolute
          bottom-8
          left-1/2
          hidden
          -translate-x-1/2
          text-sm
          text-slate-500
          lg:block
        "
      >
        Scroll Down ↓
      </motion.div>
    </section>
  );
}
