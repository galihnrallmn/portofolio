import Container from "@/components/shared/Container";
import Section from "@/components/shared/Section";
import SectionTitle from "@/components/shared/SectionTitle";
import EducationCard from "@/components/shared/EducationCard";

import { educations } from "@/data/education";
import Reveal from "@/components/ui/Reveal";

export default function Education() {
  return (
    <Section id="education">
      <Reveal>
        <Container>
          <SectionTitle title="Education" subtitle="Academic Journey" />

          <div className="space-y-8">
            {educations.map((education) => (
              <EducationCard key={education.year} education={education} />
            ))}
          </div>
        </Container>
      </Reveal>
    </Section>
  );
}
