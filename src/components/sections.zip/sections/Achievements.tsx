import Container from "@/components/shared/Container";
import Section from "@/components/shared/Section";
import SectionTitle from "@/components/shared/SectionTitle";
import AchievementCard from "@/components/shared/AchievementCard";

import { achievements } from "@/data/achievements";
import Reveal from "@/components/ui/Reveal";

export default function Achievements() {
  return (
    <Section id="achievements">
      <Reveal>
      <Container>
        <SectionTitle title="Achievements" subtitle="Highlights" />

        <div className="space-y-8">
          {achievements.map((achievement) => (
            <AchievementCard key={achievement.title} {...achievement} />
          ))}
        </div>
      </Container>
      </Reveal>
    </Section>
  );
}
