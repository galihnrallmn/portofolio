import Container from "../shared/Container";
import SectionTitle from "../shared/SectionTitle";
import TimelineItem from "../shared/TimelineItem";

import { experiences } from "../../data/experiences";
import Reveal from "@/components/ui/Reveal";

export default function Experience() {
  return (
    <section id="experience" className="py-28">
      <Reveal>
        <Container>
          <SectionTitle title="Experience" subtitle="Journey" />
          <div className="space-y-16">
            {experiences.map((item) => (
              <TimelineItem key={item.year} {...item} />
            ))}
          </div>
        </Container>
      </Reveal>
    </section>
  );
}
